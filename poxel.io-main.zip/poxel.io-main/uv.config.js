window.__uv$config = {
  prefix: '/p',
  encodeUrl: function(url) {
    return encodeURIComponent(url);
  },
};
